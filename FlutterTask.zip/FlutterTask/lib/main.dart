import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'localization/app_localizations.dart';
import 'screens/home_screen.dart';
import 'screens/available_doctors_screen.dart';
import 'screens/calendar_screen.dart';
import 'screens/history_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Doctor Appointment',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('en', ''),
        Locale('es', ''),
      ],
      localeResolutionCallback: (locale, supportedLocales) {
        return supportedLocales.firstWhere(
          (supportedLocale) =>
              supportedLocale.languageCode == locale?.languageCode,
          orElse: () => const Locale('en', ''),
        );
      },
      home: HomeScreen(), // 🔥 REMOVE 'const' here
      routes: {
        '/availableDoctors': (context) => AvailableDoctorsScreen(), // 🔥 REMOVE 'const'
        '/calendar': (context) => CalendarScreen(), // 🔥 REMOVE 'const'
        '/history': (context) => HistoryScreen(), // REMOVE 'const'
      },
    );
  }
}
