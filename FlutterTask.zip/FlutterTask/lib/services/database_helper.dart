import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();
  static Database? _database;

  DatabaseHelper._privateConstructor();

  Future<Database> get database async {
    if (_database != null) return _database!;

    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'appointments.db');
    return await openDatabase(
      path,
      version: 2, // Increment the version to force an upgrade
      onCreate: _createDatabase,
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          await db.execute('DROP TABLE IF EXISTS appointments');
          _createDatabase(db, newVersion);
        }
      },
    );
  }

  Future<void> _createDatabase(Database db, int version) async {
    await db.execute('''
      CREATE TABLE appointments(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        age INTEGER,
        date TEXT,
        time TEXT
      )
    ''');
  }

  Future<int> insertAppointment(Map<String, dynamic> appointment) async {
    Database db = await instance.database;
    return await db.insert('appointments', appointment);
  }

  Future<List<Map<String, dynamic>>> getAppointments() async {
    Database db = await instance.database;
    return await db.query('appointments');
  }

  Future<int> deleteAppointment(int id) async {
    Database db = await instance.database;
    return await db.delete('appointments', where: 'id = ?', whereArgs: [id]);
  }
}
