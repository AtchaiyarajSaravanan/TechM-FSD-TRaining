import 'package:flutter/material.dart';

class AppLocalizations {
  final Locale locale;

  AppLocalizations(this.locale);

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  static final Map<String, Map<String, String>> _localizedValues = {
    'en': {
      'title': 'Doctor Appointment',
      'home': 'Home',
      'doctors': 'Available Doctors',
      'calendar': 'Calendar',
      'history': 'Appointment History',
    },
    'es': {
      'title': 'Cita con el Doctor',
      'home': 'Inicio',
      'doctors': 'Doctores Disponibles',
      'calendar': 'Calendario',
      'history': 'Historial de Citas',
    }
  };

  Map<String, String> get localizedStrings {
    return _localizedValues[locale.languageCode] ?? _localizedValues['en']!;
  }

  String get title => localizedStrings['title'] ?? 'Doctor Appointment';
  String get home => localizedStrings['home'] ?? 'Home';
  String get doctors => localizedStrings['doctors'] ?? 'Available Doctors';
  String get calendar => localizedStrings['calendar'] ?? 'Calendar';
  String get history => localizedStrings['history'] ?? 'Appointment History';
}

// Localization Delegate
class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => ['en', 'es'].contains(locale.languageCode);

  @override
  Future<AppLocalizations> load(Locale locale) async {
    return AppLocalizations(locale);
  }

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}
