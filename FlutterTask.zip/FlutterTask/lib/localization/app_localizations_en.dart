const Map<String, String> en = {
  "home_title": "Doctor Appointment",
  "home_available_doctors": "Available Doctors",
  "home_calendar": "Book Appointment",
  "home_history": "Appointment History",
  
  "calendar_title": "Select Appointment Date",
  "calendar_choose_date": "Choose Date",
  "calendar_proceed": "Proceed",

  "form_title": "Enter Appointment Details",
  "form_name": "Name",
  "form_age": "Age",
  "form_problem": "Problem",
  "form_book": "Book Appointment",
  
  "history_title": "Appointment History",
  "history_delete": "Delete",
  "history_no_appointments": "No Appointments Found",
};
