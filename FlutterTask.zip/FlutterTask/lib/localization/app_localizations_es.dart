const Map<String, String> es = {
  "home_title": "Cita Médica",
  "home_available_doctors": "Doctores Disponibles",
  "home_calendar": "Reservar Cita",
  "home_history": "Historial de Citas",
  
  "calendar_title": "Seleccionar Fecha de Cita",
  "calendar_choose_date": "Elegir Fecha",
  "calendar_proceed": "Continuar",

  "form_title": "Ingrese los Detalles de la Cita",
  "form_name": "Nombre",
  "form_age": "Edad",
  "form_problem": "Problema",
  "form_book": "Reservar Cita",
  
  "history_title": "Historial de Citas",
  "history_delete": "Eliminar",
  "history_no_appointments": "No se Encontraron Citas",
};
