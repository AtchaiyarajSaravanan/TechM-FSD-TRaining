import 'package:flutter/material.dart';

class AppointmentCard extends StatelessWidget {
  final Map<String, dynamic> appointment;
  final VoidCallback onDelete;

  AppointmentCard({required this.appointment, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text(appointment["name"]),
        subtitle: Text("Date: ${appointment["date"]}"),
        trailing: IconButton(icon: Icon(Icons.delete), onPressed: onDelete),
      ),
    );
  }
}
