import 'package:flutter/material.dart';

class DoctorCard extends StatelessWidget {
  final Map<String, String> doctor;

  DoctorCard({required this.doctor});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      child: ListTile(
        leading: Image.asset(doctor["image"]!),
        title: Text(doctor["name"]!),
        subtitle: Text(doctor["specialty"]!),
      ),
    );
  }
}
