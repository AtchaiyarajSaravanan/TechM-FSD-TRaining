import 'package:flutter/material.dart';
import 'package:flutterassessment/screens/appointment_form_screen.dart';

class CalendarScreen extends StatefulWidget {
  @override
  _CalendarScreenState createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  DateTime? selectedDate; // Ensure it is nullable

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(DateTime.now().year + 1),
    );

    if (picked != null) {
      setState(() {
        selectedDate = picked;
      });

      if (selectedDate != null) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => AppointmentFormScreen(selectedDate: selectedDate!),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Select Date")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Choose a Date for Appointment",
              style: TextStyle(fontSize: 18.0),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () => _selectDate(context),
              child: Text("Select Date"),
            ),
            SizedBox(height: 20),
            selectedDate == null
                ? Text("No date selected")
                : Text("Selected Date: ${selectedDate!.toLocal()}"),
          ],
        ),
      ),
    );
  }
}
