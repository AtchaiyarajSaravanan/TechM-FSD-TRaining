import 'package:flutter/material.dart';
import 'package:flutterassessment/services/database_helper.dart';

class HistoryScreen extends StatefulWidget {
  @override
  _HistoryScreenState createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<Map<String, dynamic>> _appointments = [];

  @override
  void initState() {
    super.initState();
    _loadAppointments();
  }

  /// **Fix: Renamed the method to avoid duplication**
  void _loadAppointments() async {
    final data = await DatabaseHelper.instance.getAppointments(); // 🔹 FIXED
    setState(() {
      _appointments = data;
    });
  }

  Future<void> _deleteAppointment(int id) async {
    await DatabaseHelper.instance.deleteAppointment(id);
    _loadAppointments(); // Reload data after deleting
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Appointment History")),
      body: ListView.builder(
        itemCount: _appointments.length,
        itemBuilder: (context, index) {
          final appointment = _appointments[index];
          return ListTile(
            title: Text(appointment['name']),
            subtitle: Text("Date: ${appointment['date']} - Time: ${appointment['time']}"),
            trailing: IconButton(
              icon: Icon(Icons.delete, color: Colors.red),
              onPressed: () => _deleteAppointment(appointment['id']),
            ),
          );
        },
      ),
    );
  }
}
