import 'package:flutter/material.dart';
import 'package:flutterassessment/services/database_helper.dart';

class AppointmentFormScreen extends StatefulWidget {
  final DateTime selectedDate;

  AppointmentFormScreen({required this.selectedDate});

  @override
  _AppointmentFormScreenState createState() => _AppointmentFormScreenState();
}

class _AppointmentFormScreenState extends State<AppointmentFormScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  TimeOfDay selectedTime = TimeOfDay.now(); // ✅ Removed duplicate declaration

  Future<void> _selectTime(BuildContext context) async {
    final TimeOfDay? picked = await showTimePicker(
      context: context,
      initialTime: selectedTime,
    );

    if (picked != null) {
      setState(() {
        selectedTime = picked;
      });
    }
  }

  Future<void> _saveAppointment() async {
    if (nameController.text.isEmpty || ageController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please fill all fields")),
      );
      return;
    }

    final appointment = {
      'name': nameController.text,
      'age': ageController.text,
      'date': widget.selectedDate.toString(),
      'time': selectedTime.format(context),
    };

    try {
      await DatabaseHelper.instance.insertAppointment(appointment);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Appointment booked successfully!")),
      );
      Navigator.pop(context);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Failed to book appointment")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Book Appointment")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("Appointment on: ${widget.selectedDate.toLocal()}"),
            SizedBox(height: 10),
            TextField(
              controller: nameController,
              decoration: InputDecoration(labelText: "Name"),
            ),
            SizedBox(height: 10),
            TextField(
              controller: ageController,
              decoration: InputDecoration(labelText: "Age"),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: () => _selectTime(context),
              child: Text("Select Time"),
            ),
            SizedBox(height: 10),
            Text("Selected Time: ${selectedTime.format(context)}"),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _saveAppointment,
              child: Text("Save Appointment"),
            ),
          ],
        ),
      ),
    );
  }
}
