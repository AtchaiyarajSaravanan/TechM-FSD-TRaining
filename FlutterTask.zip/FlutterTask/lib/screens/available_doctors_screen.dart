import 'package:flutter/material.dart';
import '../widgets/doctor_card.dart';

class AvailableDoctorsScreen extends StatelessWidget {
  final List<Map<String, String>> doctors = [
    {"name": "Dr. John Doe", "specialty": "Cardiologist", "image": "assets/images/doctor1.jpg"},
    {"name": "Dr. Jane Smith", "specialty": "Dermatologist", "image": "assets/images/doctor2.jpg"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Available Doctors")),
      body: ListView.builder(
        itemCount: doctors.length,
        itemBuilder: (context, index) {
          return DoctorCard(doctor: doctors[index]);
        },
      ),
    );
  }
}
