class Appointment {
  int? id;
  String name;
  int age;
  String date;
  String problem;

  Appointment({
    this.id,
    required this.name,
    required this.age,
    required this.date,
    required this.problem,
  });

  // Convert an Appointment object to a Map for database storage
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'age': age,
      'date': date,
      'problem': problem,
    };
  }

  // Convert a Map from the database to an Appointment object
  factory Appointment.fromMap(Map<String, dynamic> map) {
    return Appointment(
      id: map['id'],
      name: map['name'],
      age: map['age'],
      date: map['date'],
      problem: map['problem'],
    );
  }
}
