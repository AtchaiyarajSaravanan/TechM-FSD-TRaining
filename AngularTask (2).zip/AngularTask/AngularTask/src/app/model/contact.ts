export interface contact {
  name: string;
  address: string;
  city: string;
  state: string;
  phone: string;
  image: string;
}
