import { Component } from '@angular/core';
import { Project } from '../../model/project';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrl: './projects.component.css',
})
export class ProjectsComponent {
[x: string]: any;
  projectsList: Project[] = [];
  minTeam = 5;
  maxTeam = 15;
  selectedStatus = 'All';

  constructor(private api: ApiService) {
    
  }

  ngOnInit() {
    this.api.getProjects().subscribe({
      next: (result: Project[]) => (this.projectsList = result),
      error: (error) => console.log('Error fetching projects:', error),
    });
  }
}
