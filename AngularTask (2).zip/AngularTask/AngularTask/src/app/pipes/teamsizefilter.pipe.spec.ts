import { TeamSizeFilterPipe } from './teamsizefilter.pipe';

describe('TeamsizefilterPipe', () => {
  it('create an instance', () => {
    const pipe = new TeamSizeFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
