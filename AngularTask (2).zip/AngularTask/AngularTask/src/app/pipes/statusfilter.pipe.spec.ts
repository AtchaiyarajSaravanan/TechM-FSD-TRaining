import { StatusFilterPipe } from './statusfilter.pipe';

describe('StatusfilterPipe', () => {
  it('create an instance', () => {
    const pipe = new StatusFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
